# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file LICENSE.rst or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-src")
  file(MAKE_DIRECTORY "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-src")
endif()
file(MAKE_DIRECTORY
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-build"
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix"
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/tmp"
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/src/rabbitmq-c-populate-stamp"
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/src"
  "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/src/rabbitmq-c-populate-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/src/rabbitmq-c-populate-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/cmake-build-debug/_deps/rabbitmq-c-subbuild/rabbitmq-c-populate-prefix/src/rabbitmq-c-populate-stamp${cfgdir}") # cfgdir has leading slash
endif()
