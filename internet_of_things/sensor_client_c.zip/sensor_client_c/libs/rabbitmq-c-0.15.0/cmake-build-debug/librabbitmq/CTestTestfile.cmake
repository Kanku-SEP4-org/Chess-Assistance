# CMake generated Testfile for 
# Source directory: D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/librabbitmq
# Build directory: D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/librabbitmq
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
