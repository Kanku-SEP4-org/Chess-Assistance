#ifndef CONFIG_H
#define CONFIG_H

#define HAVE_SELECT

/* #undef HAVE_POLL */

#define AMQ_PLATFORM "Windows"

/* #undef ENABLE_SSL_ENGINE_API */

#endif /* CONFIG_H */
