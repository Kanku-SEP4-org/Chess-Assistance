# Install script for directory: D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "C:/Program Files (x86)/rabbitmq-c")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Debug")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "C:/Users/amycl/AppData/Local/Programs/CLion/bin/mingw/bin/objdump.exe")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/librabbitmq/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/tests/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "rabbitmq-c-development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c" TYPE FILE FILES
    "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/rabbitmq-c-config.cmake"
    "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/rabbitmq-c-config-version.cmake"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "rabbitmq-c-development" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c/rabbitmq-targets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c/rabbitmq-targets.cmake"
         "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/CMakeFiles/Export/e8a0c82a34091c06ddabfe986f98a2a7/rabbitmq-targets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c/rabbitmq-targets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c/rabbitmq-targets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c" TYPE FILE FILES "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/CMakeFiles/Export/e8a0c82a34091c06ddabfe986f98a2a7/rabbitmq-targets.cmake")
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Dd][Ee][Bb][Uu][Gg])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/rabbitmq-c" TYPE FILE FILES "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/CMakeFiles/Export/e8a0c82a34091c06ddabfe986f98a2a7/rabbitmq-targets-debug.cmake")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/pkgconfig" TYPE FILE FILES "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/librabbitmq.pc")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "D:/Docs/courses/SE Software Engineering/sem 4/01.SemesterProject/code/hopefully last/Chess-Assistance/internet_of_things/sensor_client_c/libs/rabbitmq-c-0.15.0/cmake-build-debug/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
